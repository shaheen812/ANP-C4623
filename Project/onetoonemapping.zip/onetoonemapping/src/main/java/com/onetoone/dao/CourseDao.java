package com.onetoone.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.onetoone.entity.Course;
import com.onetoone.util.HibernateUtil;


public class CourseDao
{
	public void saveCustomer(Course course) 
	{
		 Transaction transaction = null;
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            // start the transaction
	            transaction = session.beginTransaction();
	            session.save(course);

            // commit the transaction
	            transaction.commit();
        }
        catch (Exception e) 
        {
            if (transaction != null) 
            {
                transaction.rollback();
            }
        }
    }
}
