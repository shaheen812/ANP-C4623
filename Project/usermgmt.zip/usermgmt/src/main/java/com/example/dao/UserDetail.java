package com.example.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.example.model.User;
import com.example.model.UserD;


public class UserDetail
{
	private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    
	  public void saveUser(UserD userdetail) {
	    Transaction tx = null;
	    try (Session session = sessionFactory.openSession()) 
	    {
	      tx = session.beginTransaction();
	      session.save(userdetail);
	      tx.commit();
	    } catch (Exception e) {
	      if (tx != null) {
	        tx.rollback();
	      }
	      e.printStackTrace();
	    }
	  }
	  
	  public void updateUser(UserD userdetail) 
		{
	        Transaction tx = null;
	        try (Session session = sessionFactory.openSession()) 
	        {
	            // start the transaction
	            tx = session.beginTransaction();

	            // save student object
	            session.saveOrUpdate(userdetail);

	            // commit the transaction
	            tx.commit();
	        } 
	        catch (Exception e)
	        {
	            if (tx != null)
	            {
	                tx.rollback();
	            }
	        }
	    }
	  public void deleteUser(UserD id) {
	        Transaction tx = null;
	        UserD userdetail = null;
	        try (Session session = sessionFactory.openSession())
	        {
	            // start the transaction
	            tx = session.beginTransaction();

	            // get student object
	            session.delete(id);
	            //student = session.load(Student.class, id);
	            // commit the transaction
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	               // transaction.rollback();
	            }
	        }
	        
	        
	  
	    }
}
