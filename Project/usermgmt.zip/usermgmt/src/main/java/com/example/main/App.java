package com.example.main;
import org.hibernate.cfg.Configuration;
import com.example.model.User;
import com.example.model.UserD;
import com.example.dao.*;
public class App {
  public static void main(String[] args) 
  {
	 
	    // Create a new user entity
	    User user = new User();
	    user.setName("John Smith");
	    user.setEmail("abc@gmail.com");
		UserDao dao = new UserDao();	    
		dao.saveUser(user);
	    
	    UserD userdetail = new UserD();

	    userdetail.setAddress("abc");
	    userdetail.setEmail("john@gmail.com");
	    UserDetail dao1 = new UserDetail();
	    dao1.saveUser(userdetail);
	    dao1.updateUser(userdetail);
	    dao1.deleteUser(userdetail);
	    
	    
//	    user.setName("sha khan");
//	    user.setEmail("sha@gmail.com");
//	    dao. updateUser(user);
//	    dao.deleteUser(user);


  }
}

