package com.example.dao;
import com.example.model.User;
public interface IUserDao 
{
	void saveUser(User user);
	void updateUser(User user);
	void deleteUser(User user);

}
