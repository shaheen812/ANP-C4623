package com.example.dao;

import com.example.model.User;
import com.example.model.UserD;

public interface IUserDetail
{
	void saveUserD(UserD userdetail);
	void updateUserD(UserD userdetail);
	void deleteUserD(UserD userdetail);

}
