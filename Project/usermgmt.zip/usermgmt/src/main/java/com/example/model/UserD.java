package com.example.model;

import lombok.*;
import javax.persistence.*;

@Entity
@Table(name = "userD")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Data
public class UserD 
{
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  private int id;

	  @Column(name = "address")
	  private String address;

	  @Column(name = "email")
	  private String email;
	  
	  @OneToOne(mappedBy="userD",cascade=CascadeType.ALL)
	  @JoinColumn(name="user_Detail_id")
	  private User userr;
	  
}
