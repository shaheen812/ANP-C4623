package com.mavenproject.book_management;
import java.util.*;

import com.book.dao.bookdao;
import com.book.model.bookmngmt;
public class App 
{
    public static void main( String[] args )
    {
    	bookdao bk = new bookdao();
    	
    	bookmngmt book = new bookmngmt("Alice in Wonderland","Lewis Carol",10);
    	bookmngmt book1 = new bookmngmt("Ancient Mariner","Coleridge",10);
    	bookmngmt book2 = new bookmngmt("Picture","Lawrence",5);
    	
    	
    	bk.addBook(book);
    	bk.addBook(book1);
    	bk.addBook(book2);
    	
    	
    	book.setAuthorName("Lewis Carol");
    	bk.updateBook(book);
    	
    	List<bookmngmt> books = bk.getallbooks();
    	books.forEach(book3 -> System.out.println(book3.getId()));
    	
    	bk.deleteBook(3);
    }
}
