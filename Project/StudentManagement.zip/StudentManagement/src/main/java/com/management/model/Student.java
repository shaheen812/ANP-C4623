package com.management.model;
import lombok.*;
import javax.persistence.*;

@Entity
@Table(name = "studentd")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Data
public class Student 
{
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  @Column(name = "rollno")
  private int rollno;

  @Column(name = "name")
  private String name;
  
  @Column(name = "department")
  private String department;
}