package com.management.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.management.model.Student;

public class StudentDao 
	{
		private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	    
		  public void saveStudent(Student student) {
		    Transaction tx = null;
		    try (Session session = sessionFactory.openSession()) 
		    {
		      tx = session.beginTransaction();
		      session.save(student);
		      tx.commit();
		    } catch (Exception e) {
		      if (tx != null) {
		        tx.rollback();
		      }
		      e.printStackTrace();
		    }
		  }
		  
		  public Student getStudentById(int id) 
			{
		        Transaction tx = null;
		        Student student = null;
		        try (Session session =  sessionFactory.openSession()){
		            // start the transaction
		            tx = session.beginTransaction();

		            // get student object
		            student = session.get(Student.class, id);
		            //student = session.load(Student.class, id);
		            // commit the transaction
		            tx.commit();
		        } 
		        catch (Exception e)
		        {
		            if (tx != null)
		            {
		                tx.rollback();
		            }
		        }
		        return student;
		    }
		
		  public void updateStudent(Student student) 
			{
		        Transaction tx = null;
		        try (Session session = sessionFactory.openSession()) 
		        {
		            // start the transaction
		            tx = session.beginTransaction();

		            // save student object
		            session.saveOrUpdate(student);

		            // commit the transaction
		            tx.commit();
		        } 
		        catch (Exception e)
		        {
		            if (tx != null)
		            {
		                tx.rollback();
		            }
		        }
		    }
		  @SuppressWarnings("unchecked")
		    public List <Student> getAllStudent() 
			{
		        Transaction tx = null;
		        List < Student > student = null;
		        try (Session session = sessionFactory.openSession()) {
		            // start the transaction
		            tx = session.beginTransaction();

		            // get students
		            student = session.createQuery("from Student").list();
		            //student = session.load(Student.class, id);
		            // commit the transaction
		            tx.commit();
		        } catch (Exception e) {
		            if (tx != null) {
		                tx.rollback();
		            }
		        }
		        return student;
		    }
		
		  public void deleteStudent(int id) {
		        Transaction tx = null;
		        Student student= null;
		        try (Session session = sessionFactory.openSession())
		        {
		            // start the transaction
		            tx = session.beginTransaction();

		            // get student object
		            session.delete(id);
		            //student = session.load(Student.class, id);
		            // commit the transaction
		            tx.commit();
		        } catch (Exception e) {
		            if (tx != null) {
		               // transaction.rollback();
		            }
		        }
		  }
}
