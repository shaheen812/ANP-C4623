package com.management.main;

import com.management.dao.StudentDao;
import com.management.model.Student;

 class App
{

	public static void main(String[] args) 
	{
		StudentDao dao = new StudentDao();	    
	    // Create a new user entity
		Student student = new Student();
		student.setRollno(1);
	    student.setName("john");
	    student.setDepartment("IT");
	    dao.saveStudent(student);
	    
	    student.setRollno(2);
	    student.setName("abc");
	    student.setDepartment("CS");
	    dao.saveStudent(student);
	    dao.updateStudent(student);
	    dao.deleteStudent(1);

		
		
	}

}
