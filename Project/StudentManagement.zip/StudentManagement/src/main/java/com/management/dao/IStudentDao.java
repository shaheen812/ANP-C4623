package com.management.dao;

import java.util.List;

import com.management.model.Student;

public interface IStudentDao 
{
	void saveStudent(Student student);
	void updateStudent(Student student);
	Student getStudentById(int id);
	List<Student> getAllStudent();
	void deleteStudent(int id);
}
