
public class Even 
{
	public static int EvenT(int num)
	{
		int sum=0;
		for(int i=2;i<=num;i+=2)
		{
			sum+=i;
		}
		return sum;
	}

	
}
