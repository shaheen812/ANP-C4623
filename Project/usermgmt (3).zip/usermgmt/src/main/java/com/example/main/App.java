package com.example.main;
import org.hibernate.cfg.Configuration;
import com.example.model.User;
import com.example.dao.*;
public class App {
  public static void main(String[] args) 
  {
	 
		UserDao dao = new UserDao();	    
	    // Create a new user entity
	    User user = new User();
	    user.setName("John Smith");
	    user.setEmail("abc@gmail.com");
	    dao.saveUser(user);
	    user.setName("sha khan");
	    user.setEmail("sha@gmail.com");
	    dao. updateUser(user);
	    dao.deleteUser(user);


  }
}

