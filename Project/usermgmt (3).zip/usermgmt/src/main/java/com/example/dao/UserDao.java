package com.example.dao;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import com.example.model.User;
import com.example.model.User;
import lombok.extern.slf4j.*;

public class UserDao 
{
	private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    
	  public void saveUser(User user) {
	    Transaction tx = null;
	    try (Session session = sessionFactory.openSession()) 
	    {
	      tx = session.beginTransaction();
	      session.save(user);
	      tx.commit();
	    } catch (Exception e) {
	      if (tx != null) {
	        tx.rollback();
	      }
	      e.printStackTrace();
	    }
	  }
	  
	  public void updateUser(User user) 
		{
	        Transaction tx = null;
	        try (Session session = sessionFactory.openSession()) 
	        {
	            // start the transaction
	            tx = session.beginTransaction();

	            // save student object
	            session.saveOrUpdate(user);

	            // commit the transaction
	            tx.commit();
	        } 
	        catch (Exception e)
	        {
	            if (tx != null)
	            {
	                tx.rollback();
	            }
	        }
	    }
	  public void deleteUser(User id) {
	        Transaction tx = null;
	        User user = null;
	        try (Session session = sessionFactory.openSession())
	        {
	            // start the transaction
	            tx = session.beginTransaction();

	            // get student object
	            session.delete(id);
	            //student = session.load(Student.class, id);
	            // commit the transaction
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	               // transaction.rollback();
	            }
	        }
	  
    }
}
