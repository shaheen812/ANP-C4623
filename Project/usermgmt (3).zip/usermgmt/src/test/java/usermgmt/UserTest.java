package usermgmt;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.example.model.User;

class UserTest {

	@Test
	public void testSaveUser()
	{
		User user = new User();
	    user.setName("John Smith");
	    user.setEmail("abc@gmail.com");
	    Assert.assertEquals("John Smith",user.getName());
	    Assert.assertEquals("abc@gmail.com",user.getEmail());
	}


}
