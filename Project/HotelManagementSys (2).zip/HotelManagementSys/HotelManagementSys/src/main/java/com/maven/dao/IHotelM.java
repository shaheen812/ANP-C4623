package com.maven.dao;

import com.maven.model.HotelManagement;

import antlr.collections.List;

public interface IHotelM 
{
	void saveCustomer(HotelManagement customer);

    void updateCustomer(HotelManagement customer);

    HotelManagement getCustomerById(int id);

    List getAllCustomers();

    void deleteCustomer(int id);
}
