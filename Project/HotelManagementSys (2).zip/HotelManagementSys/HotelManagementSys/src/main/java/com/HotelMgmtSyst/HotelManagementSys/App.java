package com.HotelMgmtSyst.HotelManagementSys;

import java.util.List;

import com.maven.dao.HotelM;
import com.maven.model.HotelManagement;


public class App 
{
    public static void main( String[] args )
    {
    	HotelM hm = new HotelM();

    	HotelManagement customer =new HotelManagement( "John", "Doe", "johndoe@example.com",101,3693);
    	HotelManagement customer1 =new HotelManagement( "John", "Doe", "johndoe@example.com",102,1293);
        hm.saveCustomer(customer);
        hm.saveCustomer(customer1);
        
        customer.setFirstName("John");
        hm.updateCustomer(customer1);
        

        List <HotelManagement > customers = hm.getAllCustomers();
        customers.forEach(Customer2 -> System.out.println(Customer2.getId()));
        
        hm.deleteCustomer(2);

    }
    }

