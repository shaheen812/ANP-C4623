package com.maven.dao;

import com.maven.model.HotelManagement;

import java.util.List;

public interface IHotelM 
{
	void saveCustomer(HotelManagement student);

	void updateCustomer(HotelManagement student);

	HotelManagement getStudentById(long id);
	
	List<HotelManagement> getAllStudents();

	void deleteCustomer(long id);


}
