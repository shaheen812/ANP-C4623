package com.HotelManagement.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HotelManagement.DTO.RoomDTO;
import com.HotelManagement.Model.Room;
import com.HotelManagement.Repository.RoomRepository;
	@Service
	public class RoomService
	{

	    @Autowired
	    private RoomRepository roomRepository;

	    public Room save(Room room)
	    {
	        return roomRepository.save(room);
	    }

	    public List<Room> getAllRooms()
	    {
	        return roomRepository.findAll();
	    }

	    private Room convertToEntity(RoomDTO roomDTO)
	    {
	        Room room = new Room();
	        // Set the properties of the room entity based on the roomDTO
	        room.setRoomNumber(roomDTO.getRoomNumber());
	        room.setType(roomDTO.getType());
	        room.setPrice(roomDTO.getPrice());
	        // ... set other properties as needed

	        return room;
	    }

	    public Room addRoom(RoomDTO roomDTO)
	    {
	        // Convert RoomDTO to Room entity
	        Room room = convertToEntity(roomDTO);

	        // Save the room entity using the roomRepository
	        return roomRepository.save(room);
	    }

	    public Room getRoomById(Long id)
	    {
	        return roomRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Room not found for id: " + id));
	    }

	    public Room updateRoom(Room room)
	    {
	        return roomRepository.save(room);
	    }

	    public void deleteRoom(Long id)
	    {
	        roomRepository.deleteById(id);
	    }
	}