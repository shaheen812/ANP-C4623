package com.HotelManagement.Service;

import com.HotelManagement.DTO.GuestDTO;
import com.HotelManagement.DTO.LoginDTO;

public interface GuestService {
	void registerGuest(GuestDTO guestDTO);
	  String login(LoginDTO loginDTO);
}
