//package com.HotelManagement.Model;
//
//import java.sql.Date;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.ManyToOne;
//import javax.persistence.Table;
//
//@Table(name = "booking")
//@Entity
//public class Booking
//{
//	@Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//    private Date checkInDate;
//    private Date checkOutDate;
//
//    
//
//
//}
