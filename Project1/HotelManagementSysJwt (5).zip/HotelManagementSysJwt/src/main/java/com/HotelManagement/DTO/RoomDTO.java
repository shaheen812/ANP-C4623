package com.HotelManagement.DTO;

import lombok.Data;

@Data
public class RoomDTO
{
	private Long id;
    private int roomNumber;
    private int type;
    private double price;

}