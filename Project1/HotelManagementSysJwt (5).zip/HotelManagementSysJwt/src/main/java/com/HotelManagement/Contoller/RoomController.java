package com.HotelManagement.Contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.HotelManagement.Model.Room;
import com.HotelManagement.Service.RoomService;

@RestController
@RequestMapping("/rooms")
	public class RoomController {
	 @Autowired
	    private RoomService roomService;

	    @PostMapping
	    @ResponseStatus(HttpStatus.CREATED)
	    public Room createRoom(@RequestBody Room room) {
	        return roomService.save(room);
	    }

	    @GetMapping
	    @ResponseStatus(HttpStatus.OK)
	    public List<Room> getAllRooms() {
	        return roomService.getAllRooms();
	    }

	    @GetMapping("/{id}")
	    @ResponseStatus(HttpStatus.OK)
	    public Room getRoomById(@PathVariable Long id) {
	        return roomService.getRoomById(id);
	    }

	    @DeleteMapping("/{id}")
	    @ResponseStatus(HttpStatus.NO_CONTENT)
	    public void deleteRoom(@PathVariable Long id) {
	        roomService.deleteRoom(id);
	    }

	    @PutMapping("/{id}")
	    @ResponseStatus(HttpStatus.OK)
	    public Room updateRoom(@PathVariable Long id, @RequestBody Room room) {
	        return roomService.updateRoom( room);
	    }
	}