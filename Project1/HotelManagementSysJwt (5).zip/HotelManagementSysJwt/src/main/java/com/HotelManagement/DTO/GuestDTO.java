package com.HotelManagement.DTO;

import lombok.Data;

@Data
public class GuestDTO
{
	private String name;

    private String email;

    private String password;
    
    private int roomno;
    
    private Long phoneno;

}


