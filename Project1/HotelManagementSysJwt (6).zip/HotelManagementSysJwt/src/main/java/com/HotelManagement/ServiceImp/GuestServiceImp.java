package com.HotelManagement.ServiceImp;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.HotelManagement.DTO.GuestDTO;
import com.HotelManagement.DTO.LoginDTO;
import com.HotelManagement.Exception.BadRequestExcpetion;
import com.HotelManagement.Model.Guest;
import com.HotelManagement.Model.Room;
import com.HotelManagement.Repository.GuestRepository;
import com.HotelManagement.Repository.RoomRepository;
import com.HotelManagement.Service.GuestService;
import com.HotelManagement.Util.JwtUtil;

@Service
@Transactional
public class GuestServiceImp implements GuestService
{
	@Autowired
    private GuestRepository guestRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

   // @Override
    @Override
	public void registerGuest(GuestDTO guestDTO) {
        Optional<Room> optionalRoom = roomRepository.findByRoomNumber(guestDTO.getRoomno());
        if(optionalRoom.isEmpty())
        {
           throw new BadRequestExcpetion("Select a valid role.");
        }

       Guest guest=Guest.builder()
        				.name(guestDTO.getName())
                  	.email(guestDTO.getEmail())
                  	.phoneno(guestDTO.getPhoneno())
                  	.roomno(guestDTO.getRoomno())
                  	.password(passwordEncoder.encode
                      		(guestDTO.getPassword()))
                  	.build();
          guestRepository.save(guest);
      }

    @Override
	public String login(LoginDTO loginDTO) {
        Optional<Guest> guestOptional = guestRepository.findByEmail(loginDTO.getEmail());
        if (guestOptional.isEmpty()) {
            throw new BadRequestExcpetion("Guest not found");
        }
        Guest guest = guestOptional.get();
        if (passwordEncoder.matches(loginDTO.getPassword(), guest.getPassword())) {
            return jwtUtil.generateAccessToken(guest);
        } else {
            throw new BadRequestExcpetion("Invalid email or password");
        }
    }

}