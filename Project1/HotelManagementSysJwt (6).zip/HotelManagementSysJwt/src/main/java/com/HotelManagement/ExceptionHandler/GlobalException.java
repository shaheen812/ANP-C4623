package com.HotelManagement.ExceptionHandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.HotelManagement.DTO.ResponseDTO;
import com.HotelManagement.Exception.BadRequestExcpetion;

public class GlobalException 
{
	private final Logger logger= 
	    	LoggerFactory.getLogger(GlobalException.class);

	    @ExceptionHandler({BadRequestExcpetion.class})
	    public ResponseEntity<ResponseDTO> 
	    		handleBadRequestException(BadRequestExcpetion e)
	    {
	      logger.info("Bad Request Found {} ",e.getMsg(),e);
	      return new ResponseEntity<>(
	      	ResponseDTO.builder().
	        	responseMsg(e.getMsg()).build(),
				HttpStatus.BAD_REQUEST);
	    }

	    @ExceptionHandler({Exception.class})
	    public ResponseEntity<ResponseDTO> 
	    			handleException(Exception e)
	    {
	      logger.info("Unknown error occur {} ",
	      	e.getMessage(),e);
	      
	      return new ResponseEntity<>(
	      		ResponseDTO.builder()
	            	.responseMsg(e.getMessage()).build(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}