package com.HotelManagement.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Table(name = "room")
@Data
@Entity
public class Room
{
	@Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="roomNumber",length = 5)
    private int roomNumber;
	
	@Column(name="type",length = 10)
    private String type;
	
	@Column(name="price",length = 10)
    private double price;
    
    

}
