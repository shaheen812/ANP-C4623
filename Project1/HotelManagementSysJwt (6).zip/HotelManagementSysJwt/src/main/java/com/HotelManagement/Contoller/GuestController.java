package com.HotelManagement.Contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HotelManagement.DTO.GuestDTO;
import com.HotelManagement.DTO.LoginDTO;
import com.HotelManagement.DTO.ResponseDTO;
import com.HotelManagement.Service.GuestService;

@RestController
@RequestMapping("/guest")
public class GuestController
{
	 @Autowired
	    private GuestService guestService;

	    @PostMapping("/register")
	    public ResponseEntity<ResponseDTO>
	    	addUser(@RequestBody GuestDTO guestDTO){

	        guestService.registerGuest(guestDTO);
	        return new ResponseEntity<>
	        	(ResponseDTO.builder()
	            	.responseMsg("Guest register successfully.")
					.build(), HttpStatus.CREATED);
	    }

	    @PostMapping("/login")
	    public ResponseEntity<ResponseDTO>
	    	login(@RequestBody LoginDTO  loginDTO){

	        String token = guestService.login(loginDTO);
	        return new ResponseEntity<>
	        	(ResponseDTO.builder()
	            	.json(token)
	                .responseMsg("Login successful.")
					.build(), HttpStatus.OK);
	    }
	}
