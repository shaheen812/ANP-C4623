package com.HotelManagement.DTO;

import lombok.Data;

@Data
public class RoomDTO
{
	private Long id;
    private int roomNumber;
    private String type;
    private double price;

}