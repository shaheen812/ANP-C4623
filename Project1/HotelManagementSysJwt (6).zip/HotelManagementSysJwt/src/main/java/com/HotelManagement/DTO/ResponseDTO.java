package com.HotelManagement.DTO;

import lombok.Builder;
import lombok.Data;
@Data
@Builder
public class ResponseDTO<T>{
	 private String responseMsg;

	    private T json;
	}
