package com.HotelManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelManagementSysJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelManagementSysJwtApplication.class, args);
		System.out.println("Springboot JWT Application is Running........");
	}

}
