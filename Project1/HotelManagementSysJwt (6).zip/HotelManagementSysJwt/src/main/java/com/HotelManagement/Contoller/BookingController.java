//package com.HotelManagement.Contoller;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.HotelManagement.DTO.ResponseDTO;
//
//
//@RestController
//public class BookingController
//{
//	private final Logger logger=
//	    	LoggerFactory.getLogger(BookingController.class);
//
//	    @PostMapping("/booking")
//	    @PreAuthorize("hasAuthority('Customer')")
//	    public ResponseEntity<ResponseDTO> addProduct(){
//
//	    //NOTE This method is just to check add product
//	    	//is called or not.
//
//	     logger.info("Add booking room called successfully.");
//
//	     return new ResponseEntity<>(
//	        ResponseDTO.builder().responseMsg("Room Added.")
//			.build(), HttpStatus.CREATED);
//	    }
//	}
