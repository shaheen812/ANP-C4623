package com.HotelManagement.Model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "guest")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Guest
{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	@Column(name="name",length = 50)
    private String name;
	
	@Column(name="email",unique = true)
    @Pattern(regexp = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$", message = "Invalid email format")
    private String email;
	
	@Column(name="password")
    @Size(min = 6, max = 20, message = "Password must be between 6 and 20 characters")
    private String password;
	
	@Column(name="roomno",length = 5)
    private int roomno;
	
	@Column(name="phoneno",length = 10)
    private Long phoneno;
    
	//one guest can  assign one room
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="room_id" ,referencedColumnName="id" )
    private Room room;
    
//    @ManyToOne(cascade=CascadeType.PERSIST)
//    private Booking booking;
}
