package com.StudentMgmtSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMgmtSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
