//package com.StudentMgmtSystem.request;
//
//
//
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Setter
//@Getter
//
//	public class StudentRequest
//	{
//		
//		private String Studentname ;
//		
//		private String  course;
//		
//		private String Address ;
//		
//		private Long PhoneNo;
//		
//	}


