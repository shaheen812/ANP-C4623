package com.StudentMgmtSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentMgmtSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentMgmtSystemApplication.class, args);
		System.out.println("Application is Running.......");
	}

}
