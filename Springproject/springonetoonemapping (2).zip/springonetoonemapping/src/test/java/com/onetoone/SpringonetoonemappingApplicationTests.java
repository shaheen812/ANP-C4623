package com.onetoone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringonetoonemappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
